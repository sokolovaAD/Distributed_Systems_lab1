#define _GNU_SOURCE
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "common.h"
#include "ipc.h"
#include "pa2345.h"


typedef struct {
    int readfd, writefd;
}__attribute__((packed)) PipeFD;

typedef struct {
    local_id src_pid;
    PipeFD *channel_table;
    size_t proc_num;
    pid_t parent_pid;
    local_id last_msg_pid;
} Data;


typedef struct Queue {
    struct Queue *front, *back, *next;
    local_id pid;
    timestamp_t time;
} Queue;

timestamp_t proc_time = 0;
Queue *queue = NULL;
size_t done_cnt = 0;
uint8_t mutex_enabled;

static int events_log_fd = -1;

static const char e_no_args[]  = "Error: not enough arguments\n";
static const char e_proc_num[] = "Error: number of processes should be from 1 to 10\n";

static const char e_log_write[] = "Error: failed to write event read log\n";
static const char e_log_multicast[] = "Error: failed to send multicast\n";
static const char e_log_multicast_read[] = "Error: failed to read multicast\n";

timestamp_t getLamportTime(){
	return proc_time;
}

timestamp_t setLamportTime(timestamp_t new_time){
	proc_time = new_time > proc_time ? new_time : proc_time;
    return proc_time;
}

void incTime(){
	proc_time++;
}

void create_message(Message *msg, MessageType type, size_t length){
    memset(msg, 0, sizeof *msg);
    msg->s_header.s_magic = MESSAGE_MAGIC;
    msg->s_header.s_type = type;
    msg->s_header.s_local_time = getLamportTime();
    msg->s_header.s_payload_len = length;
}

void queue_push( Queue *queue, local_id pid, timestamp_t time ) {

    Queue *node;
    node = malloc( sizeof *node );
    node->pid   = pid;
    node->time  = time;
    node->next  = NULL;

    if( queue->front == NULL && queue->back == NULL ){
        queue->front = queue->back = node;
        return;
    }

    Queue *current = queue->front;
    Queue *prev = NULL;

    while( current != NULL ) {
        if( current->time > time
            || ( current->time == time && pid < current->pid ) ) {

            node->next = current;
            if( prev ) prev->next = node;

            if( current == queue->front ) queue->front = node;

            node = NULL;
            break;
        } else {
            prev = current;
            current = current->next;
        }
    }

    if( node ) {
        queue->back->next = node;
        queue->back = node;
        node = NULL;
    }
}

void QPop(Queue *queue ) {

    if( queue->front == NULL ) return;
    Queue *del = queue->front;
    if( queue->front == queue->back ) {
        queue->front = NULL;
        queue->back = NULL;
    }else {
        queue->front = queue->front->next;
    }
    free(del);
}


int request_cs(const void * self) {
    Data *handle = (Data*)self;
    Message msg;
    incTime();
    create_message(&msg, CS_REQUEST, 0);
    if( queue == NULL ){
        queue = malloc( sizeof *queue );
    }

    queue_push(queue, handle->src_pid, getLamportTime());
    int rc = send_multicast(handle, &msg);
    if( rc != 0 ) return rc;

    int replies_cnt = handle->proc_num - 2;
    while( replies_cnt > 0 || queue->front->pid != handle->src_pid ){
        rc = receive_any(handle, &msg);
        if( rc != 0 ) return rc;
        setLamportTime(msg.s_header.s_local_time);
        incTime();
        switch(msg.s_header.s_type){
            case CS_REQUEST:
                queue_push(queue, handle->last_msg_pid, msg.s_header.s_local_time);
                incTime();
                create_message(&msg, CS_REPLY, 0);
                int rc = send(handle, handle->last_msg_pid, &msg);
                if( rc != 0 ) return rc;
                break;
            case CS_RELEASE:
                QPop(queue);
                break;
            case CS_REPLY:
                replies_cnt--;
                break;
            case DONE:
                done_cnt++;
                break;
        }
    }

    return 0;
}


uint8_t childWork(Data *handle, void *data) {
	if( mutex_enabled )
		request_cs( handle);

	char buff[4096];

	int n = handle->src_pid * 5;
	for( int i = 1; i <= n; i++ ) {
		snprintf( buff, sizeof(buff), log_loop_operation_fmt, handle->src_pid, i, n );
		print( buff );
	}
	if( mutex_enabled )
		release_cs( handle );
	return 0;
}

int child_atexit(Data *handle, void *data){
	return 0;
}


int log_event(char *msg){
    int rc = write(events_log_fd, msg, strlen(msg));
    if( rc < 0 ){
        (void)write(STDERR_FILENO, e_log_write, sizeof e_log_write);
        return 1;
    }
    return 0;
}

static void close_pipes(Data *handle){
    for(int i = 0; i < handle->proc_num; i++){
        for(int j = 0; j < handle->proc_num; j++){
            if( i == j ) continue;
            if( i != handle->src_pid ){
                close(handle->channel_table[i * handle->proc_num + j].writefd);
            }
            if( j != handle->src_pid ){
                close(handle->channel_table[i * handle->proc_num + j].readfd);
            }
        }
    }
}


static PipeFD *get_channel(Data *handle, local_id from, local_id to){
    if( from < 0 && from > handle->proc_num ) return NULL;
    if( to   < 0 && to   > handle->proc_num ) return NULL;
    return &handle->channel_table[from * handle->proc_num + to];
}

int send(void * self, local_id dst, const Message * msg) {

    Data *h = (Data*)self;
    if( dst == h->src_pid ) return 0;

    PipeFD *c = get_channel(h, h->src_pid, dst);
    if( c == NULL ) return -1;

    size_t msg_size = sizeof msg->s_header + msg->s_header.s_payload_len;
    int rc = write(c->writefd, msg, msg_size);
    if( rc < 0 || rc != msg_size ) return -1;

    return 0;
}

int send_multicast(void * self, const Message * msg) {

    Data *h = (Data*)self;

    for(local_id pid = 0; pid < h->proc_num; pid++){
        int rc = send(self, pid, msg);
        if( rc < 0 ) return -1;
    }
    return 0;
}

int receive(void * self, local_id from, Message * msg) {

    Data *h = (Data*)self;
    if( from == h->src_pid ) return 0;

    PipeFD *c = get_channel(h, from, h->src_pid);
    if( c == NULL ) return -1;

    while( 1 ){
        int rc = read(c->readfd, msg, sizeof msg->s_header);
        if( rc <= 0 ) {
            goto sleep;
        }
        rc = read(c->readfd, msg->s_payload, msg->s_header.s_payload_len);
        if( rc >= 0 ) {
            return 0;
        }
        sleep:
        usleep(1000);
    }
}

int receive_any(void * self, Message * msg) {

    Data *h = (Data*)self;
    while( 1 ){
        for(local_id pid = 0; pid < h->proc_num; pid++){
            if( pid == h->src_pid ) continue;

            PipeFD *c = get_channel(h, pid, h->src_pid);
            if( c == NULL ) return -1;

            int rc = read(c->readfd, msg, sizeof msg->s_header);
            if( rc <= 0 ) {
                continue;
            }
            rc = read(c->readfd, msg->s_payload, msg->s_header.s_payload_len);
            if( rc >= 0 ) {
                h->last_msg_pid = pid;
                return 0;
            }
        }
        usleep(1000);
    }
    return 0;
}

static int receive_all(Data *handle){
    Message msg;
    create_message(&msg, 0, 0);
    for(local_id i = 1; i < handle->proc_num - done_cnt; i++){
        int rc = receive(handle, i, &msg);
        if( rc != 0 ){
            (void)write(STDERR_FILENO, e_log_multicast_read, sizeof e_log_multicast);
            return 1;
        }
        setLamportTime(msg.s_header.s_local_time);
        incTime();
    }
    return 0;
}

int get_proc_num_from_args(int argc, char *const argv[], void *data) {
    if( argc < 2 ) {
        (void)write(STDERR_FILENO, e_no_args, sizeof e_no_args);
        return -1;
    }

    struct option long_opts[] = {
            {"mutexl", no_argument, (int*)data, 1},
            {0, 0, 0, 0}
    };

    int proc_num = 0, opt = 0;
    char *endp = NULL;
    while( ( opt = getopt_long(argc, argv, "p:", long_opts, NULL) ) != -1 ) {
        switch( opt ) {
            case 0: break;
            case 'p':
                proc_num = strtoul(optarg, &endp, 10);
                if ( *endp != '\0' || proc_num == 0 || proc_num > 10 ) {
                    (void)write(STDERR_FILENO, e_proc_num, sizeof e_proc_num);
                    return -1;
                }
                break;
            case -1: return -1;
        }
    }
    proc_num++; // include parent id

    return proc_num;
}


int create_pipes(Data *handle) {
    int pipes_log_fd = open(pipes_log, O_CREAT | O_WRONLY | O_TRUNC | O_APPEND, 0644);
    if( pipes_log_fd < 0 ) return 1;

    char msg[64];
    for(int32_t i = 0; i < handle->proc_num; i++){
        for(int32_t j = 0; j < handle->proc_num; j++){
            if( i == j ) continue;
            int	rc = pipe2((int*)&handle->channel_table[i * handle->proc_num + j], O_NONBLOCK);
            snprintf(msg, 64, "opened pipe(%d, %d)\n", i, j);
            int n = write(pipes_log_fd, msg, strlen(msg));
            if( n  < 0 ) return 1;
            if( rc < 0 ) return 1;
        }
    }
    return 0;
}

int spawn_childs(Data *handle) {
    events_log_fd = open(events_log, O_CREAT | O_WRONLY | O_TRUNC | O_APPEND, 0644);
    if( events_log_fd < 0 ) return 1;

    int is_parent = 1;
    for(local_id pid = 1; pid < handle->proc_num; pid++){
        int sys_pid = fork();
        if( sys_pid < 0 ) return -1;
        if( sys_pid == 0 ){
            is_parent = 0;
            handle->src_pid = pid;
            break;
        }
    }

    return is_parent;
}

int parent(Data *handle){
    close_pipes(handle);
    int rc = 0;
    Message msg;
    create_message(&msg, 0, 0);
    rc = receive_all(handle);
    if( rc != 0 ) return 1;

    // Do work

    while(done_cnt < handle->proc_num - 1){
        rc = receive_any(handle, &msg);
        if( rc != 0 ) return 1;
        setLamportTime(msg.s_header.s_local_time);
        incTime();
        if( msg.s_header.s_type == DONE ) done_cnt++;
    }

    if( rc != 0 ) return 1;

    for(local_id pid = 1; pid < handle->proc_num; pid++){
        wait(NULL);
    }
    return 0;
}

int child(Data *handle, void *data) {
    close_pipes(handle);
    char log_buff[MAX_PAYLOAD_LEN];
    int rc = 0;
    incTime();

    Message msg;
    create_message(&msg, STARTED, 0);
    snprintf(msg.s_payload, MAX_PAYLOAD_LEN, log_started_fmt, getLamportTime(),
             handle->src_pid, getpid(), handle->parent_pid, 0);
    msg.s_header.s_payload_len = strlen(msg.s_payload);

    rc = log_event(msg.s_payload);
    if( rc != 0 ) return 1;

    rc = send_multicast(handle, &msg);
    if( rc != 0 ){
        (void)write(STDERR_FILENO, e_log_multicast, sizeof e_log_multicast);
        return 1;
    }

    rc = receive_all(handle);
    if( rc != 0 ) return 1;

    snprintf(log_buff, MAX_PAYLOAD_LEN, log_received_all_started_fmt,
             getLamportTime(), handle->src_pid);

    rc = log_event(log_buff);
    if( rc != 0 ) return 1;

    // Do work
    childWork(handle, data);


    snprintf(msg.s_payload, MAX_PAYLOAD_LEN, log_done_fmt,
             getLamportTime(), handle->src_pid, 0);
    incTime();
    msg.s_header.s_local_time = getLamportTime();

    msg.s_header.s_payload_len = strlen(msg.s_payload);
    msg.s_header.s_type = DONE;

    rc = log_event(msg.s_payload);
    if( rc != 0 ) return 1;

    rc = send_multicast(handle, &msg);
    if( rc < 0 ){
        (void)write(STDERR_FILENO, e_log_multicast, sizeof e_log_multicast);
        return 1;
    }

    while(done_cnt < handle->proc_num - 2){
        rc = receive_any(handle, &msg);
        if( rc != 0 ) return 1;
        setLamportTime(msg.s_header.s_local_time);
        incTime();
        if( msg.s_header.s_type == DONE ) done_cnt++;
    }

    snprintf(log_buff, MAX_PAYLOAD_LEN, log_received_all_done_fmt,
             getLamportTime(), handle->src_pid);
    rc = log_event(log_buff);
    if( rc != 0 ) return 1;

    return child_atexit(handle, data);
}




int release_cs(const void * self) {
    Data *handle = (Data*)self;

    QPop(queue);
    Message msg;
    incTime();
    create_message(&msg, CS_RELEASE, 0);

    int rc = send_multicast(handle, &msg);
    if( rc != 0 ) return rc;

    return 0;
}



int main(int argc, char * argv[]) {
	int rc = 0;

	uint8_t mutex_enabled_ = 0;
	int proc_num = get_proc_num_from_args(argc, argv, &mutex_enabled_);
	if( proc_num < 0 ) return 1;

	Data handle;
    PipeFD *channel_table = malloc(proc_num * proc_num * sizeof *channel_table);
    if( channel_table == NULL ) return 1;

    memset(&handle, 0, sizeof handle);
    handle.proc_num = proc_num;
    handle.channel_table = channel_table;
    handle.parent_pid = getpid();
	mutex_enabled = mutex_enabled_;

	rc = create_pipes(&handle);
	if( rc != 0 ) return rc;

	int is_parent = spawn_childs(&handle);
	if( is_parent < 0 ) return 2;

	if( is_parent ){
		rc = parent(&handle);
	}else{
		rc = child(&handle, NULL);
	}

	free(handle.channel_table);
	return rc;

}
