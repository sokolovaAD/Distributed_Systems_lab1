#ifndef NETWORK_H
#define NETWORK_H

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include "ipc.h"


typedef struct process1 {
        int id;
        int desc_num;
        int  readPipe[MAX_PROCESS_ID];
        int writePipe[MAX_PROCESS_ID];
} Process1;

int waitAll(Process1 *process, int16_t type);
int makeNet(int x, Process1 *process, FILE *pipe_log, int *read, int *write);
int makePipes(int x, FILE *pipe_log, int *read, int *write);

void network(int x, FILE *pipe_log, Process1 *process);
void processClose(Process1 *process);


#endif //NETWORK_H
