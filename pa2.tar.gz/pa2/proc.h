#ifndef PROC_H
#include "ipc.h"
#include <sys/types.h>
#include <stdio.h>

typedef struct process {
        uint8_t id;
        uint8_t fildes_num;
        int  read_fildes[MAX_PROCESS_ID];
        int write_fildes[MAX_PROCESS_ID];
} Process;

int await_all(Process *me, int16_t type);
int init(uint8_t n, Process *proc, FILE *log);
void pipe_close(Process *proc);

#endif /* #ifndef PROC_H */
