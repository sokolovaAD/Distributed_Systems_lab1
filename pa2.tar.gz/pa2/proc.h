#ifndef PA_KHAL_PROC_H
#include "ipc.h"
#include <sys/types.h>
#include <stdio.h>

typedef struct process {
        uint8_t id;
        uint8_t fildes_num;
        int  read_fildes[MAX_PROCESS_ID];
        int write_fildes[MAX_PROCESS_ID];
} Process;

int await_all(Process *me, int16_t type);
int proc_init(uint8_t n, Process *proc, FILE *log);
void proc_destruct(Process *proc);

#endif /* #ifndef PA_KHAL_PROC_H */
