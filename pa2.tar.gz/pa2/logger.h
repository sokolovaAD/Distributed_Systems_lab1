#ifndef LOGGER_H
#include "ipc.h"
#include <sys/types.h>
#include <stdio.h>

#include <getopt.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

struct params {
        uint8_t proc_num;
        uint16_t balances[MAX_PROCESS_ID];
        timestamp_t localtime;
} ;

int getArgs(struct params*, int argc, char *argv[]);

#endif /* #ifndef LOGGER_H */
