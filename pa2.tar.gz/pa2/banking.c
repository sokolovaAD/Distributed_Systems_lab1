#include "banking.h"
#include "ipc.h"

void transfer(void * parent_data, local_id src, local_id dst, balance_t amount) {
        Message msg;
        msg.s_header.s_magic       = MESSAGE_MAGIC;
        msg.s_header.s_payload_len = sizeof(TransferOrder);
        msg.s_header.s_type        = TRANSFER;

        TransferOrder *order = (TransferOrder *)&msg.s_payload;
        order->s_src = src;
        order->s_dst = dst;
        order->s_amount = amount;

        send(parent_data, src, &msg);

        receive(parent_data, dst, &msg);
}

