#ifndef PHASES_H
#include "ipc.h"
#include <sys/types.h>
#include <stdio.h>


void child_transfer(FILE *log, Process *me, const Message *order_msg,
                balance_t *balance, BalanceHistory *hist, timestamp_t *last);

void child_cycle(FILE *log, Process *me, balance_t balance);
void parent_cycle(Process *me);

#endif /* #ifndef PHASES_H */
