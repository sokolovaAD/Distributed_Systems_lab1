#include "common.h"
#include "ipc.h"
#include "pa2345.h"
#include "proc.h"
#include "banking.h"
#include "phases.h"

#include <getopt.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


timestamp_t localtime() {
    timestamp_t i = get_physical_time();
    return i;
}


void child_transfer(FILE *log, Process *me, const Message *order_msg,
                balance_t *balance, BalanceHistory *hist, timestamp_t *last) {

        TransferOrder *order = (TransferOrder *)(order_msg->s_payload);
        local_id from = order->s_src;
        local_id to   = order->s_dst;
        balance_t amount = order->s_amount;
        timestamp_t curr_time;
        curr_time = get_physical_time();
        
        
        for (timestamp_t t = *last; t < curr_time; ++t) {
                hist->s_history[t].s_balance_pending_in = 0;
                hist->s_history[t].s_time = t;
                hist->s_history[t].s_balance = *balance;
        }

        char entry[100];
        if (to == me->id) {
                *balance += amount;
                snprintf(entry, 100, log_transfer_in_fmt, curr_time,
                                me->id, amount, from);

                Message msg;
                msg.s_header.s_magic = MESSAGE_MAGIC;
                msg.s_header.s_payload_len = 0;
                msg.s_header.s_type = ACK;
                send(me, PARENT_ID, &msg);

        } else {
                *balance -= amount;
                snprintf(entry, 100, log_transfer_out_fmt, curr_time,
                                me->id, amount, to);

                send(me, to, order_msg);
        }

        hist->s_history[curr_time].s_balance_pending_in = 0;
        hist->s_history[curr_time].s_time = curr_time;
        hist->s_history[curr_time].s_balance = *balance;

        *last = curr_time;

        printf("%s", entry);
        fprintf(log, "%s", entry);

}

void child_cycle(FILE *log, Process *me, balance_t balance) {

        BalanceHistory hist;
        hist.s_id = me->id;
        timestamp_t last_time = get_physical_time();


        for (timestamp_t t = 0; t < last_time; ++t) {
                hist.s_history[t].s_balance_pending_in = 0;
                hist.s_history[t].s_time = t;
                hist.s_history[t].s_balance = balance;
        }

        /* STAGE I */

        char entry[100];
        size_t size = snprintf(entry, 100, log_started_fmt,
                        get_physical_time(),
                        me->id, getpid(), getppid(), balance);
        printf("%s", entry);
        fprintf(log, "%s", entry);

        Message msg;
        msg.s_header.s_magic       = MESSAGE_MAGIC;
        msg.s_header.s_payload_len = size;
        msg.s_header.s_type        = STARTED;
        strncpy(msg.s_payload, entry, MAX_PAYLOAD_LEN);
        send_multicast(me, &msg);

        await_all(me, STARTED);

        snprintf(entry, 100, log_received_all_started_fmt,
                        get_physical_time(), me->id);
        printf("%s", entry);
        fprintf(log, "%s", entry);

        /* STAGE II */

        char procs_stopped = 0;

        while (1) {
                receive_any(me, &msg);
                if (msg.s_header.s_type == STOP) {
                        break;
                }
                switch (msg.s_header.s_type) {
                        case DONE:
                                ++procs_stopped;
                                break;
                        case TRANSFER:
                                child_transfer(log, me, &msg, &balance,
                                                &hist, &last_time);
                                break;
                }
        }

        /* STAGE III */

        size = snprintf(entry, 100, log_done_fmt,
                        get_physical_time(), me->id, balance);
        printf("%s", entry);
        fprintf(log, "%s", entry);

        msg.s_header.s_payload_len = size;
        msg.s_header.s_type        = DONE;
        strncpy(msg.s_payload, entry, MAX_PAYLOAD_LEN);
        send_multicast(me, &msg);

        while (procs_stopped < me->fildes_num - 2) {
                receive_any(me, &msg);
                switch (msg.s_header.s_type) {
                        case DONE:
                                ++procs_stopped;
                                break;
                        case TRANSFER:
                                child_transfer(log, me, &msg, &balance,
                                                &hist, &last_time);
                                break;
                }
        }

        timestamp_t curr_time = get_physical_time();
        for (timestamp_t t = last_time; t <= curr_time; ++t) {
                hist.s_history[t].s_balance_pending_in = 0;
                hist.s_history[t].s_time = t;
                hist.s_history[t].s_balance = balance;
        }
        hist.s_history_len = curr_time + 1;

        msg.s_header.s_payload_len = sizeof(BalanceHistory);
        msg.s_header.s_type = BALANCE_HISTORY;

        memcpy(msg.s_payload, &hist, sizeof(BalanceHistory));
        send(me, PARENT_ID, &msg);

        snprintf(entry, 100, log_received_all_done_fmt,
                        get_physical_time(), me->id);
        printf("%s", entry);
        fprintf(log, "%s", entry);
}

void parent_cycle(Process *me) {
        await_all(me, STARTED);

        bank_robbery(me, me->fildes_num - 1);

        Message msg;
        msg.s_header.s_magic       = MESSAGE_MAGIC;
        msg.s_header.s_payload_len = 0;
        msg.s_header.s_type        = STOP;
        send_multicast(me, &msg);

        await_all(me, DONE);

        AllHistory hist;
        hist.s_history_len = me->fildes_num - 1;

        for (uint8_t i = 1; i < me->fildes_num; ++i) {
                receive(me, i, &msg);
                
                if (msg.s_header.s_type != BALANCE_HISTORY) {
                        fprintf(stderr, "Not a history\n");
                }

                memcpy(&hist.s_history[i - 1], msg.s_payload,
                                sizeof(BalanceHistory));
        }

        print_history(&hist);

        for (uint8_t i = 0; i < me->fildes_num - 1; ++i) {
                int wstatus = 0;
                wait(&wstatus);
        }
}


