#include "logger.h"

int getArgs(struct params* params, int argc, char *argv[]) {
       params->proc_num = 2;

        int c;
        while ((c = getopt(argc, argv, "p:")) != -1) {
        switch (c) {
        case 'p': params->proc_num=strtol(optarg,NULL,10); break;
        }
    }

        int bal_idx = 0;
        while (optind < argc) {
                char *eptr = NULL;
                unsigned long val = strtoul(argv[optind++], &eptr, 10);
                if (*eptr) {
                        return 1;
                }
                params->balances[bal_idx++] = val;
        }
        
        return 0;

}
