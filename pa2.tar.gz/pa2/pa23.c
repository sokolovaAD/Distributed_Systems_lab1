#include "common.h"
#include "ipc.h"
#include "pa2345.h"
#include "proc.h"
#include "banking.h"
#include "phases.h"

#include <getopt.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

struct settings {
        uint8_t proc_num;
        uint16_t balances[MAX_PROCESS_ID];
        timestamp_t localtime;
};


int settings_init(struct settings* settings, int argc, char *argv[]) {

        settings->proc_num = 2;

        int c;
        while ((c = getopt(argc, argv, "p:")) != -1) {
        switch (c) {
        case 'p': settings->proc_num=strtol(optarg,NULL,10); break;
        }
    }

        int bal_idx = 0;
        while (optind < argc) {
                char *eptr = NULL;
                unsigned long val = strtoul(argv[optind++], &eptr, 10);
                if (*eptr) {
                        return 1;
                }
                settings->balances[bal_idx++] = val;
        }

        return 0;

}

int main(int argc, char *argv[]) {
        struct settings settings;
        settings_init(&settings, argc, argv);
        uint8_t n = settings.proc_num;
        FILE *pipe_log = fopen(pipes_log, "w");
        FILE *event_log = fopen(events_log, "w");

        Process me;
        proc_init(n + 1, &me, pipe_log);
        fclose(pipe_log);

        if (me.id != PARENT_ID) {
                child_cycle(event_log, &me, settings.balances[me.id - 1]);
        } else {
                parent_cycle(&me);
        }

        proc_destruct(&me);

        return 0;
}
