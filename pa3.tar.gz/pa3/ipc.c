#include "ipc.h"
#include "network.h"

#include <unistd.h>
#include <stdio.h>
#include <errno.h>

int send(void * self, local_id dst, const Message * msg) {
        Process *p = (Process *)self;
        if (write(p->writePipe[dst], (char *)msg, sizeof(MessageHeader) +
                                msg->s_header.s_payload_len) == -1) {
                perror("sending");
                return 1;
        }
        return 0;
}

int send_multicast(void * self, const Message * msg) {
        Process *p = (Process *)self;
        for (uint8_t i = 0; i < p->desc_num; ++i) {
                if (i == p->id)
                        continue;

                if (send(self, i, msg)) {
                        return 1;
                }
        }
        return 0;
}

int receive(void * self, local_id from, Message * msg) {
        Process *p = (Process *)self;
        while (read(p->readPipe[from], (char *)&(msg->s_header),
                                sizeof(MessageHeader)) == -1)
        {
                if (errno != EAGAIN) {
                        printf("receiving1\n");
                        return 1;
                }
        }
        set_lamport_time(msg->s_header.s_local_time);
        uint16_t payload_len = msg->s_header.s_payload_len;
        while (read(p->readPipe[from], (char *)msg->s_payload,
                                payload_len) != payload_len) {
                printf("receiving2\n");
                return 1;
        }
        return 0;
}

int receive_any(void * self, Message * msg) {
        Process *p = (Process *)self;
        int status;
        while (1) {
                for (size_t i = 0; i < p->desc_num; ++i) {
                        if (i == p->id) {
                                continue;
                        }

                        status = read(p->readPipe[i],
                                        (char *)&(msg->s_header),
                                                sizeof(MessageHeader));
                        if (status <= 0) {
                                continue;
                        }
                        set_lamport_time(msg->s_header.s_local_time);
                        uint16_t payload_len = msg->s_header.s_payload_len;
                        if (payload_len == 0) {
                                return 0;
                        }
                        read(p->readPipe[i], (char *)&(msg->s_payload),
                                        payload_len);
                        return 0;
                }
        }
        return 1;
}

