#ifndef PA23_H
#include "ipc.h"
#include <sys/types.h>
#include <stdio.h>



#include <sys/wait.h>

#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "common.h"

#include "pa2345.h"
#include "network.h"
#include "banking.h"


void child_transfer(FILE *log, Process *me, const Message *order_msg,
                balance_t *balance, BalanceHistory *hist, timestamp_t *last);

void child_cycle(FILE *log, Process *me, balance_t balance);
void parent_cycle(Process *me);

#endif /* #ifndef PA23_H */
