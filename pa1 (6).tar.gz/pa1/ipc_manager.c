#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "ipc.h"
#include "common.h"
#include "pa1.h"
#include "ipc_common.h"
#include "logger.h"
#include "ipc_manager.h"

PipeFd *pipes;

void do_work(int process_count){
  open_log_files();
  InteractionInfo *interaction_info = (InteractionInfo*)malloc(sizeof(InteractionInfo));
  interaction_info->s_process_count = process_count;
  init_array(interaction_info);
  open_pipes(interaction_info);
  fork_processes(process_count, interaction_info);
  parent_work(interaction_info);
  close_log_files();
}

void init_array(InteractionInfo* interaction_info){
  int process_count = interaction_info->s_process_count;
  for(int i =0 ; i<process_count; i++)
  {
    for (int j =0 ; j<process_count ; j++){
      if(i!=j){
        PipeFd * pipeFd = (PipeFd*)malloc(sizeof(PipeFd));
        interaction_info->s_pipes[i][j] = pipeFd;
      }
    }
  }
}

void open_pipes(InteractionInfo* interaction_info){
  int process_count = interaction_info ->s_process_count;
  int fds[2];
  for (int i = 0; i < process_count; i++){
    for (int j = 0; j < process_count; j++){
    	if (i != j){
        pipe(fds);
        interaction_info->s_pipes[i][j]->s_write_fd = fds[1];
        log_pipe(OPEN, 0, i, j, interaction_info->s_pipes[i][j]->s_write_fd);

        interaction_info->s_pipes[j][i]->s_read_fd = fds[0];
        log_pipe(OPEN, 0, j, i, interaction_info->s_pipes[j][i]->s_read_fd);
    	  }
      }
    }
}

pid_t* fork_processes(int process_count, InteractionInfo* interaction_info){
  pid_t* all_pids =(pid_t*)malloc(sizeof(pid_t)); ;
  all_pids[0] = getpid();
  for (local_id i = 1; i<process_count; i++){
    all_pids[i] = fork();
    if(all_pids[i]==0){
      pipe_work(i, interaction_info);
      exit(0);
    }
    else if (all_pids[i]==-1){
      //log_error(2);
    }
  }
  return all_pids;
}

void close_redundant_pipes(InteractionInfo* interaction_info){
  PipeFd* pipe_fd;
  local_id id = interaction_info->s_current_id;
  for (local_id i = 0; i < interaction_info->s_process_count; i++){
    if (i == id) continue;
    for (local_id j = 0; j < interaction_info->s_process_count; j++){
       if (i != j){
	        pipe_fd = interaction_info->s_pipes[i][j];
          log_pipe(CLOSE,id, i, j, pipe_fd->s_write_fd);
    	    close(pipe_fd->s_write_fd);
          log_pipe(CLOSE, id, i, j, pipe_fd->s_read_fd);

    	    close(pipe_fd->s_read_fd);
       }
    }
  }
}

void close_self_pipes(InteractionInfo* interaction_info){
  PipeFd* pipe_fd;
  local_id id = interaction_info->s_current_id;
  for (local_id i = 0; i < interaction_info->s_process_count; i++){
    if (i != id){
      pipe_fd = interaction_info->s_pipes[id][i];
      log_pipe(CLOSE,id, id, i, pipe_fd->s_write_fd);
      close(pipe_fd->s_write_fd);
      log_pipe(CLOSE, id, id, i, pipe_fd->s_read_fd);

      close(pipe_fd->s_read_fd);
	   }
  }
}

void parent_work(InteractionInfo* interaction_info){
  local_id id = 0;
  interaction_info->s_current_id = id;
  close_redundant_pipes(interaction_info);

  Message receive_msg;/// = (Message*)malloc(sizeof(Message);
  receive_any(interaction_info, &receive_msg);
  log_event(RECEIVED_ALL_STARTED_EVENT, id);
  receive_any(interaction_info, &receive_msg);

  log_event(RECEIVED_ALL_DONE_EVENT, id);
  wait_children();
  close_self_pipes(interaction_info);


  free(pipes);
}

void pipe_work(local_id id, InteractionInfo* interaction_info){
  interaction_info->s_current_id = id;
  close_redundant_pipes(interaction_info);
  wait_other_start(interaction_info);
  wait_other_done(interaction_info);
  close_self_pipes(interaction_info);
}

void wait_other_start(InteractionInfo* interaction_info){
  local_id id = interaction_info->s_current_id;
  log_event(STARTED_EVENT, id);

  Message msg = create_message(MESSAGE_MAGIC, id, STARTED, time(NULL));
  //printf("wait other process %d text: %s\n", id, msg.s_payload);
  if (send_multicast(interaction_info, &msg)!=0){
    exit(1);
  }


  Message receive_msg;/// = (Message*)malloc(sizeof(Message);
  //printf("wait other receive process %d text: %s\n", id, "");

  receive_any(interaction_info, &receive_msg);
  //printf("wait other receive process %d text: %s\n", id, receive_msg.s_payload);
  log_event(RECEIVED_ALL_STARTED_EVENT, id);
}

void wait_other_done(InteractionInfo* interaction_info){
  local_id id = interaction_info->s_current_id;
  log_event(DONE_EVENT, id);
  Message msg = create_message(MESSAGE_MAGIC, id, DONE, time(NULL));
  if(send_multicast(interaction_info, &msg)!=0){
    exit(1);
  }

  Message receive_msg;/// = (Message*)malloc(sizeof(Message);
  receive_any(interaction_info, &receive_msg);
  //printf("%d %s %s\n", id, " receive other done", msg.s_payload);

  log_event(RECEIVED_ALL_DONE_EVENT, id);
}

void wait_children(int process_count){
  while(wait(NULL) > 0){
   }
}

Message create_message(uint16_t magic, local_id id, int16_t type, timestamp_t time){
  Message msg;
  int len;
  switch (type) {
    case DONE:
    len = sprintf(msg.s_payload, log_done_fmt, id);
      break;
    case STARTED:
    len = sprintf(msg.s_payload, log_started_fmt, id, getpid(), getppid());
      break;
  }
  msg.s_header = create_message_header(magic, len, type, time);
  return msg;
}

MessageHeader create_message_header(uint16_t magic,uint16_t len, int16_t type, timestamp_t time){
  MessageHeader header;
  header.s_magic = MESSAGE_MAGIC;
  header.s_payload_len = len;
  header.s_type = type;
  header.s_local_time = time;
  return header;
}
