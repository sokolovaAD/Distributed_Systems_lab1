#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "common.h"
#include "pa1.h"
#include "ipc.h"


// strings for pipes.log
static const char * const pipe_opend_msg =
  "Pipe for current process%d from process %d to %d with descriptor %d opend\n";
static const char * const pipe_closed_msg =
  "Pipe for current process%d from process %d to %d with descriptor %d closed\n";

  typedef enum {
      STARTED_EVENT,
      RECEIVED_ALL_STARTED_EVENT,
      DONE_EVENT,
      RECEIVED_ALL_DONE_EVENT
  } EventLogType;

  typedef enum {
    OPEN,
    CLOSE
  } PipeLogType;

void open_log_files();

void close_log_files();

void log_event(EventLogType log_type, local_id l_id);

void log_pipe(PipeLogType log_type, int current_id, int from, int to, int descriptor);
