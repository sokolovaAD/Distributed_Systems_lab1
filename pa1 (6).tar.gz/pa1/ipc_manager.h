#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include "ipc.h"
#include "common.h"
#include "pa1.h"
#include "ipc_common.h"

void do_work(int process_count);

void init_array(InteractionInfo* interaction_info);

void open_pipes(InteractionInfo* interaction_info);

pid_t* fork_processes(int process_count, InteractionInfo* interaction_info);

void close_redundant_pipes(InteractionInfo* interaction_info);

void close_self_pipes(InteractionInfo* interaction_info);

void parent_work(InteractionInfo* interaction_info);

void pipe_work(local_id id, InteractionInfo* interaction_info);

void wait_other_start(InteractionInfo* interaction_info);

void wait_other_done(InteractionInfo* interaction_info);

void wait_children();

MessageHeader create_message_header(uint16_t magic, uint16_t len, int16_t type, timestamp_t time);

Message create_message(uint16_t magic, local_id id, int16_t type, timestamp_t time);
