#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <getopt.h>
#include "ipc_manager.h"

int parse_arg(int argc, char *argv[]){
  int count = 0;
  int c;
  while ((c = getopt (argc, argv, "p:")) != -1)
  {
    switch(c)
    {
      case 'p':
        count = atoi(optarg);
        break;
      default:
        abort();
    }
  }
  return count;
}

int main(int argc, char *argv[]){
  int process_count = parse_arg(argc, argv) + 1;
  do_work(process_count);
  return 0;
}
