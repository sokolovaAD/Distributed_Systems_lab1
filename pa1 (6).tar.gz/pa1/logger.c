#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "logger.h"
#include "common.h"
#include "pa1.h"
#include "ipc.h"

int pipesLog;
int eventsLog;

void open_log_files(){
  pipesLog = open(pipes_log, O_WRONLY | O_APPEND | O_CREAT | O_TRUNC, 0777);
  eventsLog = open(events_log, O_WRONLY | O_APPEND | O_CREAT | O_TRUNC, 0777);
}

void close_log_files(){
  close(pipesLog);
  close(eventsLog);
}

void log_event(EventLogType log_type, local_id l_id)
{
  char buf[100];

  switch(log_type)
  {
    case STARTED_EVENT:
      sprintf(buf, log_started_fmt, l_id, getpid(), getppid());
      break;
    case RECEIVED_ALL_STARTED_EVENT:
      sprintf(buf, log_received_all_started_fmt, l_id);
      break;
    case DONE_EVENT:
      sprintf(buf, log_done_fmt, l_id);
      break;
    case RECEIVED_ALL_DONE_EVENT:
      sprintf(buf, log_received_all_done_fmt, l_id);
  }

  printf(buf, 0);
  write(eventsLog, buf, strlen(buf));
}

void log_pipe(PipeLogType log_type,  int current_id, int from, int to, int descriptor)
{
  char buf[100];

  switch (log_type)
    {
    case OPEN:
      sprintf(buf, pipe_opend_msg, current_id, from, to, descriptor);
      break;
    case CLOSE:
      sprintf(buf, pipe_closed_msg,current_id, from, to,descriptor);
      break;
    }
    write(pipesLog, buf, strlen(buf));
}
