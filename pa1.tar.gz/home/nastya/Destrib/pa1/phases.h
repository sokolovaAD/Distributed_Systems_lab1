#ifndef PHASES_H
#define PHASES_H

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include "network.h"
#include "ipc.h"
#include "pa1.h"
#include <sys/wait.h>

#include <getopt.h>
#include <string.h>

int startedPhase(Process *process, FILE *event_log);

int finishedPhase(Process *process, FILE *event_log);


int waitAll(Process *process, int16_t type);


#endif