#include "network.h"
#include "common.h"



int makePipes(int n, FILE *pipe_log, int *read, int *write) {
    int desc[2];
    int k=100;
    for (int i=0; i<n;i++) {
        for (int j=0; j<n;j++) {
            if (i==j) continue;
            if(pipe(desc)==-1) {
                printf("error occured while opening the pipe");
                return 2;
            }
            fprintf(pipe_log, "Pipe from process %d to %d is ready\n",
            i, j);
            read[i*k+j] = desc[0];
            write[j*k+i] = desc[1];
        }
    }
    
    return 0;
}


int makeNet(int n, Process *process, FILE *pipe_log, int *read, int *write) {
    process->id=PARENT_ID;
    process->desc_num = n;
    int k=100;
    for (int i=1; i<n; ++i) {
        pid_t pid = fork();
        if (pid==0) 
        {
            process->id = i;
            process->desc_num=n;
            break;
        }
    }
    int numW=0, numR=0;
            for (int m=0; m<n;++m) {
                for (int l=0; l<n;++l) {
                    if(numW==process->id) numW++;
                    if(numR==process->id) numR++;
                    if (m==l) continue;
                    else if (((m*k+l)<(process->id*k+k))&&((m*k+l)>=(process->id*k))) {
                            process->writePipe[numW] = write[m*k+l];
                            numW++;
                            close(read[m*k+l]);
                            fprintf(pipe_log, "proc - %d; close read - %d\n", process->id ,read[m*k+l]);
                    }   
                    else if(((m*k+l)%k)==process->id) { 
                        process->readPipe[numR] = read[m*k+l];
                        numR++;
                        close(write[m*k+l]);
                        fprintf(pipe_log, "proc - %d; close write - %d\n", process->id ,write[m*k+l]);
                        
                    }
                    else {
                        close(read[m*k+l]);
                        close(write[m*k+l]);
                        fprintf(pipe_log, "proc - %d; close read/write - %d,%d\n", process->id  ,read[m*k+l], write[m*k+l]);

                    }
                }
            }


        
    



    return 0;
}




void network(int x, FILE *pipe_log, Process *process) {
    int n = x+1;
    int read_desc[n*110];
    int write_desc[n*110];
    makePipes(n, pipe_log, read_desc, write_desc);
    makeNet(n, process, pipe_log, read_desc, write_desc);
    
}

void processClose(Process *process){
    for (int i = 0; i < process->desc_num-1; ++i) {
                if (process->id!=0) {
                    //printf("proc: %d; read/write descs are closed - %d, %d\n",process->id, process->readPipe[i], process->writePipe[i]);
                        close(process->readPipe[i]);
                        close(process->writePipe[i]);
                        
                }
                else {
                    close(process->readPipe[i]);
                }
        }
}