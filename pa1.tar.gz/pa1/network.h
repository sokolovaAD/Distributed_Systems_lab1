#ifndef NETWORK_H
#define NETWORK_H

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include "ipc.h"


typedef struct process {
        int id;
        int desc_num;
        int  readPipe[MAX_PROCESS_ID];
        int writePipe[MAX_PROCESS_ID];
} Process;

int makeNet(int x, Process *process, FILE *pipe_log, int *read, int *write);
int makePipes(int x, FILE *pipe_log, int *read, int *write);

void network(int x, FILE *pipe_log, Process *process);
void processClose(Process *process);


#endif //NETWORK_H
