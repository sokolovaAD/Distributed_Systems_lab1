#include "ipc.h"
#include "network.h"
#include <errno.h>
#include <string.h>



int send(void * process, local_id id, const Message * msg) {
        Process *p = (Process *)process;
        if (write(p->writePipe[id], (char *)msg, sizeof(Message)) == -1) {
                printf("error occured while sending a message");
                return 1;
        }
        return 0;
}

int send_multicast(void * process, const Message * msg) {
    Process *p = (Process *)process;
    if (msg->s_header.s_type==STARTED || msg->s_header.s_type==DONE) {
        int n = p->desc_num;
        for (size_t i=0; i<n; i++) {
            if(i==p->id) continue;
            send(process, i, msg);
        }

    }
    return 0;
}

int receive(void * self, local_id from, Message * msg) {
        Process *p = (Process *)self;
        Message *m = (Message *)msg;
        MessageHeader mh;
        char buf[mh.s_payload_len];
        read(p->readPipe[from],buf,  mh.s_payload_len);
        m->s_header = mh;
        strcpy(m->s_payload, buf);
        return 0;
}

int receive_any(void * self, Message * msg) {
      printf("do nothing");
      return 0;
}
