#include "phases.h"



int waitAll(Process *process, int16_t type) {
        for (uint8_t i = 1; i < process->desc_num; ++i) {
                if (i == process->id)
                        continue;
                Message msg;
                if (receive(process, i, &msg)) {
                        fprintf(stderr, "Failed to receive: p = %d, i = %d\n",
                                        process->id, i);
                        return 1;
                }
              /*  if (msg.s_header.s_type != type) {
                        fprintf(stderr, "HHH:((( \n");
                }
                */
                

        }
        return 0;
}

int startedPhase(Process *process, FILE *event_log) {
    char entry[100];
    size_t size = snprintf(entry, 100, log_started_fmt,
    process->id, getpid(), getppid());
    printf("%s", entry);
    fprintf(event_log, "%s", entry);
    Message mes;
        mes.s_header.s_magic       = MESSAGE_MAGIC;
        mes.s_header.s_payload_len = size;
        mes.s_header.s_type        = STARTED;
    if (send_multicast(process, &mes)) {
                fprintf(stderr, "Sending multicast failed\n");
        }
    waitAll(process, mes.s_header.s_type);
    snprintf(entry, 100, log_received_all_started_fmt, process->id);
    printf("%s", entry);
    fprintf(event_log, "%s", entry);
    return 0;
}




int finishedPhase(Process *process, FILE *event_log) {
    char entry[100];
    size_t size = snprintf(entry, 100, log_done_fmt, process->id);
    printf("%s", entry);
    fprintf(event_log, "%s", entry);
    Message mes;
    mes.s_header.s_payload_len = size;
    mes.s_header.s_type        = DONE;
    strncpy(mes.s_payload, entry, MAX_PAYLOAD_LEN);
    if (send_multicast(process, &mes)) {
                fprintf(stderr, "Sending multicast failed\n");
        }

    waitAll(process, mes.s_header.s_type);

    snprintf(entry, 100, log_received_all_done_fmt, process->id);
    printf("%s", entry);
    fprintf(event_log, "%s", entry);
    return 0;
}
