#include "opts.h"
#include "common.h"
#include "network.h"
#include "ipc.h"
#include "phases.h"


int main(int argc, char** argv) {
    struct params options;
    getOptions(argc, argv, &options);
    if (options.xNum>10) return 1;
    if (options.xNum<1) return 1;
    FILE *pipe_log = fopen(pipes_log, "w");
    FILE *event_log = fopen(events_log, "w");
    Process process;
    network(options.xNum, pipe_log, &process);
    fclose(pipe_log);
    
    if (process.id != PARENT_ID) {
        startedPhase(&process, event_log);
        finishedPhase(&process, event_log);
    }
    else {
        
        waitAll(&process, STARTED);
        waitAll(&process, DONE);
        for (uint8_t i = 0; i < process.desc_num - 1; ++i) {
                        int wstatus = 0;
                        wait(&wstatus);
                }
    }
    fclose(event_log);
    processClose(&process);

    return 0;
}
