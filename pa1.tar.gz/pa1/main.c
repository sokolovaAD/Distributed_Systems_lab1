#include "opts.h"
#include "common.h"
#include "network.h"
#include "ipc.h"
#include "phases.h"


int main(int argc, char** argv) {
    struct params options;
    getOptions(argc, argv, &options);
    if (options.xNum>10) return 1;
    if (options.xNum<1) return 1;
    FILE *pipe_log = fopen(pipes_log, "w");
    FILE *event_log = fopen(events_log, "w");
    Process process;
    network(options.xNum, pipe_log, &process);
    fclose(pipe_log);
    if(process.id != 0) {
        startedPhase(&process, event_log);
        finishedPhase(&process, event_log);
    }
    fclose(event_log);
    processClose(&process);

    return 0;
}
